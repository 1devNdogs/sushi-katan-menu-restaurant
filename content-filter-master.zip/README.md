Creado Con:

Content Filter
=========

A slide-in filter panel powered by CSS and jQuery.

[Article on CodyHouse](http://codyhouse.co/gem/content-filter/)

[Demo](http://codyhouse.co/demo/content-filter/index.html)

Filter plugin: [MixItUp](https://github.com/patrickkunka/mixitup) (free to use in non-commercial projects)
 
[Terms](http://codyhouse.co/terms/)
